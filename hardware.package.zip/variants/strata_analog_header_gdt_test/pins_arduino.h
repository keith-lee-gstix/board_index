/*
* Copyright (C)  Gumstix, Inc. - https://www.gumstix.com/
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License version 2 or
* (at your option) any later version as published by the Free Software
* Foundation.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
*/
#ifndef Pins_Arduino_h
#define Pins_Arduino_h

#include <avr/pgmspace.h>

#undef UHCON
#undef UHINT
#undef UHIEN
#undef UHADDR
#undef UHFNUM
#undef UHFNUML
#undef UHFNUMH
#undef UHFLEN
#undef UPINRQX
#undef UPINTX
#undef UPNUM
#undef UPRST
#undef UPCONX
#undef UPCFG0X
#undef UPCFG1X
#undef UPSTAX
#undef UPCFG2X
#undef UPIENX
#undef UPDATX
#undef TCCR2A
#undef WGM20
#undef WGM21
#undef COM2B0
#undef COM2B1
#undef COM2A0
#undef COM2A1
#undef TCCR2B
#undef CS20
#undef CS21
#undef CS22
#undef WGM22
#undef FOC2B
#undef FOC2A
#undef TCNT2
#undef TCNT2_0
#undef TCNT2_1
#undef TCNT2_2
#undef TCNT2_3
#undef TCNT2_4
#undef TCNT2_5
#undef TCNT2_6
#undef TCNT2_7
#undef OCR2A
#undef OCR2_0
#undef OCR2_1
#undef OCR2_2
#undef OCR2_3
#undef OCR2_4
#undef OCR2_5
#undef OCR2_6
#undef OCR2_7
#undef OCR2B
#undef OCR2_0
#undef OCR2_1
#undef OCR2_2
#undef OCR2_3
#undef OCR2_4
#undef OCR2_5
#undef OCR2_6
#undef OCR2_7

#define STRATA_ANALOG_HEADER_GDT_TEST

#define NUM_DIGITAL_PINS    20
#define NUM_ANALOG_PINS     0


#define TX_RX_LED_INIT	DDRD |= (1<<5), DDRB |= (1<<0)
#define TXLED0			PORTD |= (1<<5)
#define TXLED1			PORTD &= ~(1<<5)
#define RXLED0			PORTB |= (1<<0)
#define RXLED1			PORTB &= ~(1<<0)

#define digitalPinToPCICR(p)    ((((p) >= 8 && (p) <= 11) || ((p) >= 14 && (p) <= 17) || ((p) >= A8 && (p) <= A10)) ? (&PCICR) : ((uint8_t *)0))
#define digitalPinToPCICRbit(p) 0
#define digitalPinToPCMSK(p)    ((((p) >= 8 && (p) <= 11) || ((p) >= 14 && (p) <= 17) || ((p) >= A8 && (p) <= A10)) ? (&PCMSK0) : ((uint8_t *)0))
#define digitalPinToPCMSKbit(p) ( ((p) >= 8 && (p) <= 11) ? (p) - 4 : ((p) == 14 ? 3 : ((p) == 15 ? 1 : ((p) == 16 ? 2 : ((p) == 17 ? 0 : (p - A8 + 4))))))

extern const uint8_t PROGMEM analog_pin_to_channel_PGM[];
#define analogPinToChannel(P)  ( pgm_read_byte( analog_pin_to_channel_PGM + (P) ) )
#define analogInputToDigitalPin(p)  ((p < 16) ? (p) + 54 : -1)
#define digitalPinHasPWM(p)         (((p) >= 2 && (p) <= 13) || ((p) >= 44 && (p)<= 46))


/*
// gpio Interfaces
// ------------------------------------
#define GPIO_534673_PIN5 (1)

#define GPIO_534674_PIN6 (2)

#define GPIO_534675_PIN7 (3)

#define GPIO_534676_PIN8 (4)

#define GPIO_534677_PIN9 (5)

#define GPIO_534678_PIN10 (6)

#define GPIO_534679_PIN11 (7)

#define GPIO_534680_PIN12 (8)

#define GPIO_534681_PIN13 (9)

#define GPIO_534682_PIN14 (10)

#define GPIO_534683_PIN15 (11)

#define GPIO_534684_PIN16 (12)

#define GPIO_534651_RESET (13)

#define GPIO_534666_ALERT (16)

#define GPIO_534667_SELECT (19)

*/
// wire Interfaces
// ------------------------------------
#define PIN_WIRE_SCL (14)
#define PIN_WIRE_SDA (15)
static const uint8_t SCL = PIN_WIRE_SCL;
static const uint8_t SDA = PIN_WIRE_SDA;

// serial Interfaces
// ------------------------------------
#define PIN_SERIAL1_RX (17)
#define PIN_SERIAL1_TX (18)

#define SERIAL_PORT_HARDWARE_OPEN Serial1
#define SERIAL_PORT_HARDWARE Serial1

#ifdef ARDUINO_MAIN

// MICROCHIP ATMEGA32U4 / Strata_analog_header_gdt_test
//

const uint16_t PROGMEM port_to_mode_PGM[] = {
	NOT_A_PORT,
	NOT_A_PORT,
	(uint16_t) &DDRB,
	(uint16_t) &DDRC,
	(uint16_t) &DDRD,
	(uint16_t) &DDRE,
	(uint16_t) &DDRF,
};

const uint16_t PROGMEM port_to_output_PGM[] = {
	NOT_A_PORT,
	NOT_A_PORT,
	(uint16_t) &PORTB,
	(uint16_t) &PORTC,
	(uint16_t) &PORTD,
	(uint16_t) &PORTE,
	(uint16_t) &PORTF,
};

const uint16_t PROGMEM port_to_input_PGM[] = {
	NOT_A_PORT,
	NOT_A_PORT,
	(uint16_t) &PINB,
	(uint16_t) &PINC,
	(uint16_t) &PIND,
	(uint16_t) &PINE,
	(uint16_t) &PINF,
};

const uint8_t PROGMEM digital_pin_to_port_PGM[] =
{
    PD,        // D0    PD__7
    PB,        // D1    PB__0
    PB,        // D2    PB__1
    PB,        // D3    PB__2
    PB,        // D4    PB__3
    PB,        // D5    PB__4
    PB,        // D6    PB__5
    PB,        // D7    PB__6
    PB,        // D8    PB__7
    PC,        // D9    PC__7
    PD,        // D10    PD__5
    PD,        // D11    PD__6
    PE,        // D12    PE__6
    PD,        // D13    PD__4
    PD,        // D14    PD__0
    PD,        // D15    PD__1
    PF,        // D16    PF__0
    PD,        // D17    PD__2
    PD,        // D18    PD__3
    PF,        // D19    PF__1
};

const uint8_t PROGMEM digital_pin_to_bit_mask_PGM[] =
{
    _BV(7),        // D0    PD7
    _BV(0),        // D1    PB0
    _BV(1),        // D2    PB1
    _BV(2),        // D3    PB2
    _BV(3),        // D4    PB3
    _BV(4),        // D5    PB4
    _BV(5),        // D6    PB5
    _BV(6),        // D7    PB6
    _BV(7),        // D8    PB7
    _BV(7),        // D9    PC7
    _BV(5),        // D10    PD5
    _BV(6),        // D11    PD6
    _BV(6),        // D12    PE6
    _BV(4),        // D13    PD4
    _BV(0),        // D14    PD0
    _BV(1),        // D15    PD1
    _BV(0),        // D16    PF0
    _BV(2),        // D17    PD2
    _BV(3),        // D18    PD3
    _BV(1),        // D19    PF1
};

const uint8_t PROGMEM digital_pin_to_timer_PGM[] =
{
    TIMER4D,        // 1 - PD7

    NOT_ON_TIMER,        
    NOT_ON_TIMER,        
    NOT_ON_TIMER,        
    NOT_ON_TIMER,        
    NOT_ON_TIMER,        
    NOT_ON_TIMER,        
    NOT_ON_TIMER,        
    NOT_ON_TIMER,        
    NOT_ON_TIMER,        
    NOT_ON_TIMER,        
    NOT_ON_TIMER,        
    NOT_ON_TIMER,        
    NOT_ON_TIMER,        
    NOT_ON_TIMER,        
    NOT_ON_TIMER,        
    NOT_ON_TIMER,        
    NOT_ON_TIMER,        
    NOT_ON_TIMER,        
    NOT_ON_TIMER,        
};

const uint8_t PROGMEM analog_pin_to_channel_PGM[] =
{
};

#endif //ARDUINO_MAIN

#define SERIAL_PORT_MONITOR         Serial
#define SERIAL_PORT_USBVIRTUAL      Serial
#define SerialUSB SERIAL_PORT_USBVIRTUAL


// Pins defined by Pad ID
// ----------------------
#define PD7 0   // timer4d
#define PB0 1   // gpio
#define PB1 2   // gpio
#define PB2 3   // gpio
#define PB3 4   // gpio
#define PB4 5   // gpio
#define PB5 6   // gpio
#define PB6 7   // gpio
#define PB7 8   // gpio
#define PC7 9   // gpio
#define PD5 10   // gpio
#define PD6 11   // gpio
#define PE6 12   // gpio
#define PD4 13   // gpio
#define PD0 14   // scl
#define PD1 15   // sda
#define PF0 16   // gpio
#define PD2 17   // rxd
#define PD3 18   // txd
#define PF1 19   // gpio


#endif //Pins_Arduino_h