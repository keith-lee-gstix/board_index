/*
* Copyright (C)  Gumstix, Inc. - https://www.gumstix.com/
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License version 2 or
* (at your option) any later version as published by the Free Software
* Foundation.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
*/
#pragma once

#define ARDUINO_SAMD_VARIANT_COMPLIANCE 10610

#include <WVariant.h>

#define ROOMSENSE_W_GPIO

#define VARIANT_MAINOSC     (32768ul)

#define VARIANT_MCK         (48000000ul)

#define PINS_COUNT          (27u)
#define NUM_DIGITAL_PINS    (23u)
#define NUM_ANALOG_INPUTS   (6u)
#define NUM_ANALOG_OUTPUTS  (1u)

#define analogInputToDigitalPin(p)  ((p < 7u) ? (p) + 15u : -1)
#define digitalPinToPort(P)      (&(PORT->Group[g_APinDescription[P].ulPort]))
#define digitalPinToBitMask(P)   (1 << g_APinDescription[P].ulPin)
#define portOutputRegister(port) (&(port->OUT.reg))
#define portInputRegister(port)  (&(port->IN.reg))
#define portModeRegister(port)   (&(port->DIR.reg))
#define digitalPinHasPWM(P)      (g_APinDescription[P].ulPWMChannel != NOT_ON_PWM || g_APinDescription[P].ulTCChannel != NOT_ON_TIMER)


// Analog Pins
// -----------
#define PIN_A0 (13u)
#define PIN_A1 (14u)
#define PIN_A2 (15u)
#define PIN_A3 (16u)
#define PIN_A4 (17u)
#define PIN_A5 (18u)
#define PIN_DAC0 (26u)

static const uint8_t A0 = PIN_A0;
static const uint8_t A1 = PIN_A1;
static const uint8_t A2 = PIN_A2;
static const uint8_t A3 = PIN_A3;
static const uint8_t A4 = PIN_A4;
static const uint8_t A5 = PIN_A5;
static const uint8_t DAC0 = PIN_DAC0;
#define ADC_RESOLUTION 12

// serial Interfaces
// ------------------------------------
#define SERIAL_INTERFACES_COUNT 1
#define PIN_SERIAL1_RX (21u)
#define PIN_SERIAL1_TX (22u)

#define SERIAL_PORT_HARDWARE_OPEN Serial1
#define SERIAL_PORT_HARDWARE Serial1
#define PAD_SERIAL1_RX (SERCOM_RX_PAD_3)
#define PAD_SERIAL1_TX (UART_TX_PAD_2)
/*
// gpio Interfaces
// ------------------------------------
#define GPIO_INTERFACES_COUNT 7
#define GPIO_561178_PIN1 (0u)

#define GPIO_561180_PIN2 (1u)

#define GPIO_561181_PIN3 (2u)

#define GPIO_561182_PIN4 (3u)

#define PIN_LED_0 (4u)

#define GPIO_561184_PIN6 (5u)

#define GPIO_561189_PIN11 (10u)

*/
// usb Interfaces
// ------------------------------------
#define USB_INTERFACES_COUNT 1
#define PIN_USB_DM (24u)
#define PIN_USB_DP (25u)
#define PIN_USB_HOST_ENABLE (23u)

// wire Interfaces
// ------------------------------------
#define WIRE_INTERFACES_COUNT 1
#define PIN_WIRE_SCL (19u)
#define PIN_WIRE_SDA (20u)
static const uint8_t SCL = PIN_WIRE_SCL;
static const uint8_t SDA = PIN_WIRE_SDA;

#define WIRE_IT_HANDLER SERCOM0_Handler
#define PERIPH_WIRE sercom0
// led Interfaces
// ------------------------------------
#define LED_INTERFACES_COUNT 1
#define PIN_LED_0 (4u)

#define LED_BUILTIN PIN_LED_0

//WiFi 101 Builtin
// SPI1: Connected to WINC1501B
#define PIN_SPI1_MOSI (27u)
#define PIN_SPI1_SCK  (28u)
#define PIN_SPI1_SS   (29u)
#define PIN_SPI1_MISO (30u)
#define PERIPH_SPI1   sercom2
#define PAD_SPI1_TX   SPI_PAD_0_SCK_1
#define PAD_SPI1_RX   SERCOM_RX_PAD_3

static const uint8_t SS1   = PIN_SPI1_SS;
static const uint8_t MOSI1 = PIN_SPI1_MOSI;
static const uint8_t MISO1 = PIN_SPI1_MISO;
static const uint8_t SCK1  = PIN_SPI1_SCK;

#define WINC1501_RESET_PIN   (31u)
#define WINC1501_CHIP_EN_PIN (32u)
#define WINC1501_INTN_PIN    (34u)
#define WINC1501_SPI         SPI1
#define WINC1501_SPI_CS_PIN  PIN_SPI1_SS

#ifdef __cplusplus
#include "SERCOM.h"
#include "Uart.h"

extern SERCOM sercom0;
extern SERCOM sercom1;
extern SERCOM sercom2;
extern SERCOM sercom3;
extern SERCOM sercom4;
extern SERCOM sercom5;

extern Uart Serial1;


#endif

#define SERIAL_PORT_USBVIRTUAL      SerialUSB
#define SERIAL_PORT_MONITOR         SerialUSB
#define Serial                      SerialUSB


// Definition of pins by TRM PAD ID

#define PA19 0
#define PA17 1
#define PA16 2
#define PA21 3
#define PA20 4
#define PA7 5
#define PA22 6
#define PA10 7
#define PA11 8
#define PB10 9
#define PA3 10
#define PB11 11
#define PA23 12
#define PA2 13
#define PB2 14
#define PB3 15
#define PA4 16
#define PA5 17
#define PA6 18
#define PA9 19
#define PA8 20
#define PB23 21
#define PB22 22
#define PA18 23
#define PA24 24
#define PA25 25